rm storage/.installed
